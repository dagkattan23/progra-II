package empresa;

public class EmpleadoComun extends Empleado {
    private double salario;

    public EmpleadoComun(int codigo, String nombre, double salario) {
        super(codigo, nombre);
        this.salario = salario;
    }

    public double calcularPago() {
        return salario;
    }
}
