package empresa;

public class EmpleadoTemporal extends Empleado {
    private double salario;
    private String fechaFinContrato;

    public EmpleadoTemporal(int codigo, String nombre, double salario) {
        super(codigo, nombre);
        this.salario = salario;
        this.fechaFinContrato = "No definida";
    }

    public void setFechaFinContrato(String fecha) {
        this.fechaFinContrato = fecha;
    }

    public String getFechaFinContrato() {
        return fechaFinContrato;
    }

    public double calcularPago() {
        return salario;
    }
}