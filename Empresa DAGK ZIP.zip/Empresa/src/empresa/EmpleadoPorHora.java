package empresa;

public class EmpleadoPorHora extends Empleado {
    private double pagoPorHora;
    private double horasTrabajadas;

    public EmpleadoPorHora(int codigo, String nombre, double pagoPorHora) {
        super(codigo, nombre);
        this.pagoPorHora = pagoPorHora;
        this.horasTrabajadas = 0;
    }

    public void agregarHoras(double horas) {
        horasTrabajadas = horasTrabajadas + horas;
    }

    public double calcularPago() {
        return pagoPorHora * horasTrabajadas;
    }
}
