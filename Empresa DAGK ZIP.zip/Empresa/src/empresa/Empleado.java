package empresa;

public abstract class Empleado {
    protected int codigo;
    protected String nombre;

    public Empleado(int codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    
    public abstract double calcularPago();

    public String toString() {
        return "Codigo: " + codigo + " | Nombre: " + nombre + " | Pago: " + calcularPago();
    }
}
