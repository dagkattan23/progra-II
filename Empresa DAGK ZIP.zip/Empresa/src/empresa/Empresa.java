package empresa;

import java.util.ArrayList;
import java.util.Scanner;

public class Empresa {
    static ArrayList<Empleado> empleados;
    static Scanner lea = new Scanner(System.in);

    public static void main(String[] args) {
        empleados = new ArrayList<>();
        int opcion;

        do{
            System.out.println("1- Agregar Empleado");
            System.out.println("2- Pagar Empleado");
            System.out.println("3- Lista de Empleados");
            System.out.println("4- Sub Menu especifico");
            System.out.println("5- Salir");
            System.out.print("Escoja Opcion: ");
            opcion = lea.nextInt();

            switch(opcion){
                case 1:
                    hire();
                    break;
                case 2:
                    pay();
                    break;
                case 3:
                    list();
                    break;
                case 4:
                    submenu();
                    break;
            }
        }while(opcion!=5);

    }
    
    private static Empleado search(int cod){
        for(int i = 0; i < empleados.size(); i++){
            Empleado e = empleados.get(i);
            if(e.getCodigo() == cod){
                return e;
            }
        }
        return null;
    }
    
    private static void hire() {
        System.out.println("Tipo de Empleado:");
        System.out.println("1- Comun");
        System.out.println("2- Por Hora");
        System.out.println("3- Por Venta");
        System.out.println("4- Temporal");
        System.out.print("Escoger tipo de empleado: ");
        int tipo = lea.nextInt();

        System.out.print("Favor ingresar Codigo: ");
        int codigo = lea.nextInt();

        if(search(codigo) != null){
            System.out.println("El codigo ingresado ya existe, no se puede repetir.");
            return;
        }

        lea.nextLine(); 
        System.out.print("Favor ingresar nombre: ");
        String nombre = lea.nextLine();

        if(tipo == 1){
            System.out.print("Favor ingresar salario: ");
            double salario = lea.nextDouble();
            EmpleadoComun e = new EmpleadoComun(codigo, nombre, salario);
            empleados.add(e);
        } else if(tipo == 2){
            System.out.print("Favor ingresar pago por hora: ");
            double pagoHora = lea.nextDouble();
            EmpleadoPorHora e = new EmpleadoPorHora(codigo, nombre, pagoHora);
            empleados.add(e);
        } else if(tipo == 3){
            System.out.print("Favor ingresar salario base: ");
            double salarioBase = lea.nextDouble();
            System.out.print("Favor ingresar comision (ejemplo 0.05 para 5%): ");
            double comision = lea.nextDouble();
            EmpleadoPorVenta e = new EmpleadoPorVenta(codigo, nombre, salarioBase, comision);
            empleados.add(e);
        } else if(tipo == 4){
            System.out.print("Favor ingresar salario: ");
            double salario = lea.nextDouble();
            EmpleadoTemporal e = new EmpleadoTemporal(codigo, nombre, salario);
            empleados.add(e);
        } else {
            System.out.println("Tipo invalido.");
            return;
        }

        System.out.println("Empleado agregado con exito.");
    }
    
    private static void pay() {
        System.out.print("Favor ingresar codigo de empleado: ");
        int codigo = lea.nextInt();

        Empleado e = search(codigo);
        if(e == null){
            System.out.println("No existe un empleado con ese codigo.");
            return;
        }

        System.out.println("Nombre: " + e.getNombre());
        System.out.println("Pago a realizar: " + e.calcularPago());
     }
     
    private static void list() {
        if(empleados.isEmpty()){
            System.out.println("No hay empleados registrados.");
            return;
        }
        for(int i = 0; i < empleados.size(); i++){
            System.out.println(empleados.get(i));
        }
    }
    private static void submenu() {
        int opcion;
        do{
            System.out.println("1-Fecha Fin Contrato a Temporales");
            System.out.println("2-Ingresar Venta");
            System.out.println("3-Ingresar Horas de Trabajo");
            System.out.println("4-Regresar al Menu Principal");
            System.out.print("Escoja Opcion: ");
            opcion= lea.nextInt();

            switch(opcion){
                case 1:
                    setFin();
                    break;
                case 2:
                    ventas();
                    break;
                case 3:
                    horas();
            }

        }while(opcion!=4);
    }

    
    private static void setFin() {
        System.out.print("Favor ingresar codigo de empleado: ");
        int codigo = lea.nextInt();

        Empleado e = search(codigo);
        if(e == null){
            System.out.println("No existe un empleado con ese codigo.");
            return;
        }

        if(!(e instanceof EmpleadoTemporal)){
            System.out.println("Ese empleado no es temporal.");
            return;
        }

        EmpleadoTemporal temp = (EmpleadoTemporal) e;
        lea.nextLine(); 
        System.out.print("Favor ingresar fecha de final de contrato (dd/mm/aaaa): ");
        String fecha = lea.nextLine();
        temp.setFechaFinContrato(fecha);

        System.out.println("Fecha actualizada con exito.");
    }
    
    private static void ventas() {
        System.out.print("Favor ingresar codigo de empleado: ");
        int codigo = lea.nextInt();

        Empleado e = search(codigo);
        if(e == null){
            System.out.println("No existe un empleado con ese codigo.");
            return;
        }

        if(!(e instanceof EmpleadoPorVenta)){
            System.out.println("Ese empleado no es por ventas.");
            return;
        }

        EmpleadoPorVenta venta = (EmpleadoPorVenta) e;
        System.out.print("Favor ingresar monto de venta: ");
        double monto = lea.nextDouble();
        venta.agregarVenta(monto);

        System.out.println("Venta agregada con exito.");
    }
    
    private static void horas() {
        System.out.print("Favor ingresar codigo de empleado: ");
        int codigo = lea.nextInt();

        Empleado e = search(codigo);
        if(e == null){
            System.out.println("No existe un empleado con ese codigo.");
            return;
        }

        if(!(e instanceof EmpleadoPorHora)){
            System.out.println("Ese empleado no es por horas.");
            return;
        }

        EmpleadoPorHora hora = (EmpleadoPorHora) e;
        System.out.print("Favor ingresar horas trabajadas: ");
        double horasTrab = lea.nextDouble();
        hora.agregarHoras(horasTrab);

        System.out.println("Horas agregadas con exito.");
    }
}
