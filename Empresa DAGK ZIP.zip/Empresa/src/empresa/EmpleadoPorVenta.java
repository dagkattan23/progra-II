package empresa;

public class EmpleadoPorVenta extends Empleado {
    private double salarioBase;
    private double totalVentas;
    private double comision; 

    public EmpleadoPorVenta(int codigo, String nombre, double salarioBase, double comision) {
        super(codigo, nombre);
        this.salarioBase = salarioBase;
        this.comision = comision;
        this.totalVentas = 0;
    }

    public void agregarVenta(double monto) {
        totalVentas = totalVentas + monto;
    }

    public double calcularPago() {
        return salarioBase + (totalVentas * comision);
    }
}
